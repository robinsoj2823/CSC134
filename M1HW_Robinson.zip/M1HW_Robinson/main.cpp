// CSC 134
// M1HW1
// Justin Robinson
// 1/17/2019

#include <iostream>

using namespace std;

int main()
{
    //provide a brief introduction

    cout << "Hello, my name is Justin Robinson" << endl;
    cout << "I started programming C++ in " << 2019 << endl;
    cout << "There are " << 3 << " televisions in my house" << endl;
    cout << "I played multiple sports in high school:" << endl;
    cout << "\t Baseball" << endl;
    cout << "\t Basketball" << endl;
    cout << "\t Cross Country" << endl;
    return 0;
}
