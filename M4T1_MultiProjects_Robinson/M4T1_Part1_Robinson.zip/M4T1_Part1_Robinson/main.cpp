//Justin Robinson
//CSC 134
//2-19-2019
//M4T1

#include <iostream>

using namespace std;

void BigDog (int KibblesCount);




int main()
{
    BigDog (3);
    return 0;
}
